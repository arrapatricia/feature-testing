$('#c2c_car_info_c2c_vehicle_trim_id').html("&lt;option value=&gt;Select Series&lt;/option&gt;<option value=\"48701\">ACURA 3<\/option>\n<option value=\"48569\">ACURA 567<\/option>");
	   