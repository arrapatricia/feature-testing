$('#c2c_car_info_c2c_vehicle_trim_id').html("&lt;option value=&gt;Select Series&lt;/option&gt;<option value=\"17374\">2017 -<\/option>");
	   