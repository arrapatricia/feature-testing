	$("#total_premium")
		.attr("data-base-premium", "296.0")
		.html("&#8369; 296.00")
		.trigger("premium:updated", ["296.0"]);
	$("#hidden_premium").val("296.00");
