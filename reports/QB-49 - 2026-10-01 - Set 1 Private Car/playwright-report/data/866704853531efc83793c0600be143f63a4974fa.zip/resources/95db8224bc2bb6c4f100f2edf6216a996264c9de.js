	$("#total_premium")
		.attr("data-base-premium", "606.0")
		.html("&#8369; 606.00")
		.trigger("premium:updated", ["606.0"]);
	$("#hidden_premium").val("606.00");
