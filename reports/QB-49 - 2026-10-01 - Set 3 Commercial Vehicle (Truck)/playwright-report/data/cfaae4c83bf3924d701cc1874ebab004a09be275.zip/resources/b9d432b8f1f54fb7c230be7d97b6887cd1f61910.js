	$("#total_premium")
		.attr("data-base-premium", "1246.0")
		.html("&#8369; 1,246.00")
		.trigger("premium:updated", ["1246.0"]);
	$("#hidden_premium").val("1,246.00");
